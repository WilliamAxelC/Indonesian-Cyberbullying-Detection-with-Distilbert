---
license: unknown
---

this dataset are originally from kaggle 
https://www.kaggle.com/datasets/cttrhnn/cyberbullying-bahasa-indonesia/data 